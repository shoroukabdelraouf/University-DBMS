/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javax.swing.JOptionPane;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author shoroukabdelraouf
 */
public class Adding_courseController implements Initializable {

    @FXML
    private AnchorPane anchorregisteration;
    @FXML
    private Text textmakeregisteration;
    @FXML
    private TextField yearlab;
    @FXML
    private TextField cname;
    @FXML
    private TextField nohours;
    @FXML
    private TextField professorid;
    @FXML
    private TextField dname;
    @FXML
    private TextField cid;
    @FXML
    private TableColumn<prof_dto, Integer> profid;
    @FXML
    private TableColumn<prof_dto, String> profname;
    @FXML
    private TableView<prof_dto> table_prof;
    @FXML
    private TableColumn<prof_dto, String> proflname;
    private ArrayList<course_dto> course;
    @FXML
    private TableView<depart_dto> table_depart;
    @FXML
    private TableColumn<depart_dto, String> department_name;
    @FXML
    private TableView<course_dto> tablecourse;
    @FXML
    private TableColumn<course_dto, Integer> course_id;

    @FXML
    private TableColumn<course_dto, String> co_d_name;
    private TableColumn<course_dto, String> c_name;
    @FXML
    private TableColumn<course_dto, String> course_name;

    private boolean isTableVisible = false;
    @FXML
    private BorderPane bordercourse;
    @FXML
    private TextField stud_pho;
    @FXML
    private TextField prof_pho;
    @FXML
    private TextField professor_id;
    @FXML
    private Button add_s_pho;
    @FXML
    private Button del_s_ph;
    @FXML
    private Button up_p_ph;
    @FXML
    private TextField student_id;
    @FXML
    private Button add_p_ph;
    @FXML
    private Button del_p_ph;
    @FXML
    private Button up_s_ph;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    public void registerClear() {
        yearlab.clear();
        cname.clear();
        nohours.clear();
        professorid.clear();
        dname.clear();
        cid.clear();

    }

    @FXML
    private void insert_course(ActionEvent event) throws SQLException {
        try {
            System.out.println("CID: " + cid); // Check if cid is null
            System.out.println("No Hours: " + nohours);
            System.out.println("No course nsme: " + cname);
            System.out.println("No depart: " + dname);
            System.out.println("No year: " + yearlab);// Check if nohours is null
// ... repeat for other fields

            String course_id = cid.getText();
            String no_hours = nohours.getText();
            String course_name = cname.getText();
            String dep_name = dname.getText();
            String year = yearlab.getText();
            String professor_id = professorid.getText();
            if (cid.getText().isEmpty() || nohours.getText().isEmpty() || cname.getText().isEmpty() || dname.getText().isEmpty() || yearlab.getText().isEmpty()
                    || professorid.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are necessary to be filled");
                return;
            }
            boolean recordExists = DAO.checkcourse_codeExists(Integer.parseInt(course_id));

            if (recordExists) {
                // Display a message or alert that the record already exists
                JOptionPane.showMessageDialog(null, "the course code is  already exists.");
                registerClear();
            } else {
                int result;
                result = DAO.insertcourse(Integer.parseInt(course_id), course_name, Integer.parseInt(no_hours), dep_name, Integer.parseInt(year), Integer.parseInt(professor_id));
                if (result > 0) {
                    System.out.println("Insert Successfully");
                    JOptionPane.showMessageDialog(null, "Course added Successfully");
                    registerClear();
                } else {
                    System.out.println("Failed Insert");
                    JOptionPane.showMessageDialog(null, "Failed Insert");
                }

            }
        } catch (SQLException ex) {
            ex.printStackTrace(); // Print the exception stack trace for debugging
            Logger.getLogger(Adding_studentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    public void delete_course() {
        String course_id = cid.getText();
        String no_hours = nohours.getText();
        String course_name = cname.getText();
        String dep_name = dname.getText();
        String year = yearlab.getText();
        String professor_id = professorid.getText();

        if (course_name.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Course Name is necessary to be filled");
            return;
        }

        try {
            int result = DAO.deletecourse(Integer.parseInt(course_id), course_name);

            if (result > 0) {
                System.out.println("deleted Successfully");
                JOptionPane.showMessageDialog(null, "deleted successfully");
                registerClear();
            } else {
                System.out.println("Failed to delete");
            }
            Adding_courseController.this.course = DAO.getAllcourse();
        } catch (SQLException ex) {
            ex.printStackTrace(); // Print the exception stack trace for debugging
            Logger
                    .getLogger(Adding_studentController.class
                            .getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void update_course(ActionEvent event) {
        try {
            String course_id = cid.getText();
            String no_hours = nohours.getText();
            String course_name = cname.getText();
            String dep_name = dname.getText();
            String year = yearlab.getText();
            String professor_id = professorid.getText();

            if (course_id.isEmpty() || course_name.isEmpty()) {
                JOptionPane.showMessageDialog(null, "required");
                return;
            }

            int result;
            result = DAO.updatecourse(Integer.parseInt(course_id), course_name, Integer.parseInt(no_hours), dep_name, Integer.parseInt(year), Integer.parseInt(professor_id));
            if (result > 0) {
                System.out.println("updated Successfully");
                JOptionPane.showMessageDialog(null, "Course Updated Successfully");
                registerClear();
            } else {
                System.out.println("Failed update");

            }
        } catch (SQLException ex) {
            Logger.getLogger(Adding_courseController.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void pinfo(ActionEvent event) {
        // Assuming the following code is relevant for your UI update
        ObservableList<prof_dto> professor = FXCollections.observableArrayList();
        profid.setCellValueFactory(new PropertyValueFactory<>("professorId"));
        profname.setCellValueFactory(new PropertyValueFactory<>("fname"));
        proflname.setCellValueFactory(new PropertyValueFactory<>("lname"));
        try {
            professor = DAO.getProfessors();

        } catch (SQLException ex) {
            Logger.getLogger(Adding_courseController.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        table_prof.setItems(professor);

        // Toggle the visibility of the table
        isTableVisible = !isTableVisible;
        table_prof.setVisible(isTableVisible);

        // Set the visibility of other elements
        setOtherElementsVisibility(!isTableVisible);

        // Set the alignment of the table within the StackPane
        StackPane.setAlignment(table_prof, Pos.CENTER);
    }

    @FXML
    private void dinfo(ActionEvent event) {
        // Assuming the following code is relevant for your UI update
        ObservableList<depart_dto> depart = FXCollections.observableArrayList();

        department_name.setCellValueFactory(new PropertyValueFactory<>("dname"));
        try {
            depart = DAO.getdepartname();

        } catch (SQLException ex) {
            Logger.getLogger(Adding_courseController.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        table_depart.setItems(depart);

        // Toggle the visibility of the table
        isTableVisible = !isTableVisible;
        table_depart.setVisible(isTableVisible);

        // Set the visibility of other elements
        setOtherElementsVisibility(!isTableVisible);

        // Set the alignment of the table within the StackPane
        StackPane.setAlignment(table_depart, Pos.CENTER);
    }

    @FXML
    private void cinfo(ActionEvent event) {
        // Assuming the following code is relevant for your UI update
        ObservableList<course_dto> cours = FXCollections.observableArrayList();
        course_id.setCellValueFactory(new PropertyValueFactory<>("cid"));
        course_name.setCellValueFactory(new PropertyValueFactory<>("cname"));
        co_d_name.setCellValueFactory(new PropertyValueFactory<>("dname"));
        try {
            cours = DAO.getcourse();

        } catch (SQLException ex) {
            Logger.getLogger(Adding_courseController.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        tablecourse.setItems(cours);

        // Toggle the visibility of the table
        isTableVisible = !isTableVisible;
        tablecourse.setVisible(isTableVisible);

        // Set the visibility of other elements
        setOtherElementsVisibility(!isTableVisible);

        // Set the alignment of the table within the StackPane
        StackPane.setAlignment(tablecourse, Pos.CENTER);
    }

    private void setOtherElementsVisibility(boolean visible) {
        // Set the visibility of other elements (text fields) as needed
        cname.setVisible(visible);
        nohours.setVisible(visible);
        professorid.setVisible(visible);
        cid.setVisible(visible);
        dname.setVisible(visible);
        yearlab.setVisible(visible);
        // Add other text fields as needed
    }

}
