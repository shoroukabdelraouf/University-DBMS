/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author shoroukabdelraouf
 */
public class report_dto {

    
    private int cid;
    private float avg_gpa;
    private String cname;

    
     private String sname;
      private String grade;

    public report_dto( int cid, float avg_gpa, String cname, String sname, String grade) {
      
        this.cid = cid;
        this.avg_gpa = avg_gpa;
        this.cname = cname;
        this.sname = sname;
        this.grade = grade;
    }
   

    

    public float getAvg_gpa() {
        return avg_gpa;
    }

    public void setAvg_gpa(float avg_gpa) {
        this.avg_gpa = avg_gpa;
    }


    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }
    
    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

}
