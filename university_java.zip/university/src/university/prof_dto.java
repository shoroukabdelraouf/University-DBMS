/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author shoroukabdelraouf
 */
public class prof_dto {

    public prof_dto(int professorId, String fname, String lname, int salary, String address, String email, String dname) {
        this.professorId = professorId;
        this.fname = fname;
        this.lname = lname;
        this.salary = salary;
        this.address = address;
        this.email = email;
        this.dname = dname;
    }
        private int professorId; 

    public int getProfessorId() {
        return professorId;
    }

    public prof_dto(int professorId, String fname, String lname) {
        this.professorId = professorId;
        this.fname = fname;
        this.lname = lname;
    }
    

    public void setProfessorId(int professorId) {
        this.professorId = professorId;
    }
         private String fname;
         private String lname;
         private int salary;
         private String address;
         private String email;
         private String dname;

    public prof_dto(String fname, String lname, int salary, String address, String email, String dname) {
        this.fname = fname;
        this.lname = lname;
        this.salary = salary;
        this.address = address;
        this.email = email;
        this.dname = dname;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }
         
}
