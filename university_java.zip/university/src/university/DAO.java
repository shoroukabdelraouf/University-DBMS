/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.JOptionPane;
import oracle.jdbc.OracleDriver;

/**
 *
 * @author shoroukabdelraouf
 */
public class DAO {

    public static ArrayList<student_dto> getAllstudent() throws SQLException {
        ArrayList<student_dto> contacts = new ArrayList<>();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");

        PreparedStatement pst = con.prepareStatement("Select * from student");
        ResultSet res = pst.executeQuery();
        while (res.next()) {
            contacts.add(new student_dto(res.getInt(1), res.getString(2), res.getString(3), res.getString(4), res.getString(5),
                    res.getString(6), res.getString(7), res.getString(8)));
        }
        pst.close();
        con.close();
        return contacts;
    }

    public static int insertstudent(int id, String fname, String lname, String address, String email, String gender, String faculty, String dname) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("insert into student(stud_id,fname,lname,address,email,gender,faculty,dname) "
                + "values(?,?,?,?,?,?,?,?) ");

        pst.setInt(1, id);
        pst.setString(2, fname);
        pst.setString(3, lname);
        pst.setString(4, address);
        pst.setString(5, email);
        pst.setString(6, gender);
        pst.setString(7, faculty);
        pst.setString(8, dname);

        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;
    }

    public static int updatestudent(int id, String fname, String lname, String address, String email, String gender, String faculty, String dname) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        //delete
        PreparedStatement pst = con.prepareStatement("delete from student where stud_id=?");
        pst.setInt(1, id);

        result = pst.executeUpdate();
        //insert
        PreparedStatement i = con.prepareStatement("insert into student (stud_id,fname,lname,address,email,gender,faculty,dname) "
                + "values(?,?,?,?,?,?,?,?) ");
        i.setInt(1, id);
        i.setString(2, fname);
        i.setString(3, lname);
        i.setString(4, address);
        i.setString(5, email);
        i.setString(6, gender);
        i.setString(7, faculty);
        i.setString(8, dname);
        result = i.executeUpdate();

        pst.close();
        con.close();
        return result;
    }

    public static int deletestudent(int id, String fname, String lname, String address, String email, String gender, String faculty, String dname) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("delete from student where stud_id=?");

        pst.setInt(1, id);
        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;
    }

    public static ResultSet getstudent(int id) throws SQLException {
        //int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("select fname||' '||lname||' at faculty of  '||faculty||' in '||dname||' depart'\n"
                + "from student \n"
                + "where stud_id=?");

        pst.setInt(1, id);
        ResultSet result = pst.executeQuery();
        //pst.close();
        //con.close();
        return result;
    }

    static void closeConnection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /* course pane*/
    public static ObservableList<prof_dto> getProfessors() throws SQLException {
        //int result = 0;
        ObservableList<prof_dto> professor = FXCollections.observableArrayList();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("SELECT PROFESSOR_ID, FNAME, LNAME FROM PROFESSOR");
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            professor.add(new prof_dto(result.getInt(1), result.getString(2), result.getString(3)));
        }
        pst.close();
        return professor;
    }

    public static ObservableList<student_dto> get_student_info() throws SQLException {
        //int result = 0;
        ObservableList<student_dto> student = FXCollections.observableArrayList();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("SELECT stud_ID, FNAME, LNAME,ACC_GPA FROM student");
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            student.add(new student_dto(result.getInt(1), result.getString(2), result.getString(3), result.getFloat(4)));
        }
        pst.close();
        return student;
    }

    public static ObservableList<stud_pho> getstud_con() throws SQLException {
        //int result = 0;
        ObservableList<stud_pho> student = FXCollections.observableArrayList();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("SELECT *FROM stud_pho");
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            student.add(new stud_pho(result.getInt(1), result.getString(2)));
        }
        pst.close();
        return student;
    }

    public static ObservableList<report_dto> course_gpa_info(String id) throws SQLException {
        //int result = 0;
        ObservableList<report_dto> course_gpa = FXCollections.observableArrayList();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("SELECT\n"
                + "    c.cid AS \"Course code\", c.c_name AS \"Course name\", CALCULATE_AVG_GPA(c.cid) AS average_gpa,  s.fname ||' '|| s.lname AS \"Student name\",sc.grade_ as\"student grade\"\n"
                + "FROM Course c\n"
                + "JOIN  Stud_course sc ON c.cid = sc.cid\n"
                + "JOIN Student s ON sc.stud_id = s.stud_id\n"
                + "WHERE  c.cid = ?");
        pst.setInt(1, Integer.valueOf(id));
        ResultSet result = pst.executeQuery();
             if (!result.isBeforeFirst()) {
        // No rows returned, meaning there are no students enrolled in the course
        JOptionPane.showMessageDialog(null, "There are no students enrolled in this course yet.");
        System.out.println("There are no students enrolled in this course yet.");
        // You can also display a dialog or label to inform the user
    } else {
        while (result.next()) {
            //course_gpa.add(new report_dto(result.getInt(1), result.getFloat(3), result.getString(2), result.getString(4), result.getString(5)));
            course_gpa.add(new report_dto(
                    result.getInt("Course code"), // Make sure the column names match the aliases in the SQL query
                    result.getFloat("average_gpa"),
                    result.getString("Course name"),
                    result.getString("Student name"),
                    result.getString("student grade")
            ));
        }
             }

        pst.close();
        return course_gpa;
    }
    

    public static ObservableList<prof_pho_dto> getprof_con() throws SQLException {
        //int result = 0;
        ObservableList<prof_pho_dto> professor = FXCollections.observableArrayList();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("SELECT *FROM prof_pho");
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            professor.add(new prof_pho_dto(result.getInt(1), result.getString(2)));
        }
        pst.close();
        return professor;
    }

    public static ObservableList<prof_dto> getmanager() throws SQLException {
        //int result = 0;
        ObservableList<prof_dto> manager = FXCollections.observableArrayList();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("SELECT PROFESSOR_ID, FNAME, LNAME FROM PROFESSOR");
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            manager.add(new prof_dto(result.getInt(1), result.getString(2), result.getString(3)));
        }
        pst.close();
        return manager;
    }

    public static ObservableList<prof_dto> getProfessor() throws SQLException {
        //int result = 0;
        ObservableList<prof_dto> professor_prof = FXCollections.observableArrayList();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("SELECT * FROM PROFESSOR");
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            professor_prof.add(new prof_dto(result.getInt(1), result.getString(2), result.getString(3), result.getInt(4), result.getString(5), result.getString(6), result.getString(7)));
        }
        pst.close();
        return professor_prof;
    }

    public static ObservableList<depart_dto> getdepartname() throws SQLException {
        //int result = 0;
        ObservableList<depart_dto> depart = FXCollections.observableArrayList();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("SELECT dname FROM department");
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            depart.add(new depart_dto(result.getString(1)));
        }
        pst.close();
        return depart;
    }

    public static ObservableList<depart_dto> getdepartments() throws SQLException {
        //int result = 0;
        ObservableList<depart_dto> departments = FXCollections.observableArrayList();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("SELECT *FROM department");
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            departments.add(new depart_dto(result.getString(1), result.getString(2), result.getInt(3)));
        }
        pst.close();
        return departments;
    }

    public static ObservableList<depart_dto> getdepart_name() throws SQLException {
        //int result = 0;
        ObservableList<depart_dto> department = FXCollections.observableArrayList();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("SELECT dname FROM department");
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            department.add(new depart_dto(result.getString(1)));
        }
        pst.close();
        return department;
    }

    public static ObservableList<course_dto> getcourse() throws SQLException {
        //int result = 0;
        ObservableList<course_dto> cours = FXCollections.observableArrayList();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("SELECT cid ,C_NAME,dname FROM course");
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            cours.add(new course_dto(result.getInt(1), result.getString(2), result.getString(3)));
        }
        pst.close();
        return cours;
    }

    public static ArrayList<course_dto> getAllcourse() throws SQLException {
        ArrayList<course_dto> contacts = new ArrayList<>();
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");

        PreparedStatement pst = con.prepareStatement("Select * from course");
        ResultSet res = pst.executeQuery();
        while (res.next()) {
            contacts.add(new course_dto(res.getInt(1), res.getString(2), res.getInt(3), res.getString(4), res.getInt(5),
                    res.getInt(6)));
        }
        pst.close();
        con.close();
        return contacts;
    }

    public static int insertcourse(int course_id, String course_name, int no_hours, String dep_name, int year, int professor_id) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("insert into course(cid,c_name,c_hours ,dname,year ,professor_id) "
                + "values(?,?,?,?,?,?) ");

        pst.setInt(1, course_id);
        pst.setString(2, course_name);
        pst.setInt(3, no_hours);
        pst.setString(4, dep_name);
        pst.setInt(5, year);
        pst.setInt(6, professor_id);

        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;
    }

    public static int updatecourse(int course_id, String course_name, int no_hours, String dep_name, int year, int professor_id) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        //delete
        PreparedStatement pst = con.prepareStatement("delete from course where cid=?");
        pst.setInt(1, course_id);

        result = pst.executeUpdate();
        //insert
        PreparedStatement i = con.prepareStatement("insert into course(cid,c_name,c_hours ,dname,year ,professor_id) "
                + "values(?,?,?,?,?,?) ");
        i.setInt(1, course_id);
        i.setString(2, course_name);
        i.setInt(3, no_hours);
        i.setString(4, dep_name);
        i.setInt(5, year);
        i.setInt(6, professor_id);
        result = i.executeUpdate();

        pst.close();
        con.close();
        return result;
    }

    public static int deletecourse(int course_id, String course_name) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("delete from course where CID=? and C_NAME=?");
        pst.setInt(1, course_id);
        pst.setString(2, course_name);
        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;
    }

    /*professor pane*/
    public static int insertprofessor(int professorId, String fname, String lname, int salary, String address, String email, String dname) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("insert into professor(professor_id,fname,lname,salary,address,email,dname) "
                + "values(?,?,?,?,?,?,?) ");

        pst.setInt(1, professorId);
        pst.setString(2, fname);
        pst.setString(3, lname);
        pst.setInt(4, salary);
        pst.setString(5, address);
        pst.setString(6, email);
        pst.setString(7, dname);

        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;
    }

    public static int updateprofessor(int id, String fname, String lname, int salary, String add, String email, String depart) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        //delete
        PreparedStatement pst = con.prepareStatement("delete from professor where professor_id=?");
        pst.setInt(1, id);

        result = pst.executeUpdate();
        //insert
        PreparedStatement i = con.prepareStatement("insert into professor(professor_id,fname,lname,salary,address,email,dname) "
                + "values(?,?,?,?,?,?,?) ");
        i.setInt(1, id);
        i.setString(2, fname);
        i.setString(3, lname);
        i.setInt(4, salary);
        i.setString(5, add);
        i.setString(6, email);
        i.setString(7, depart);
        result = i.executeUpdate();

        pst.close();
        con.close();
        return result;
    }

    public static int deleteprof(int prof_id) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("delete from professor where professor_id=? ");
        pst.setInt(1, prof_id);

        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;
    }

    public static int insertdepartment(String depart_name, String depart_desc, int manager) throws SQLException {

        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("insert into department(DNAME , DEPT_DESCRIPTION,MANAGER_ID ) "
                + "values(?,?,?) ");

        pst.setString(1, depart_name);
        pst.setString(2, depart_desc);
        pst.setInt(3, manager);

        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;

    }

    public static int insertstudent_contact(int id, String stu_pho) throws SQLException {

        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("insert into stud_pho values(?,?) ");

        pst.setInt(1, id);
        pst.setString(2, stu_pho);

        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;

    }

    public static boolean checkStudentContactExists(int id, String phone) throws SQLException {
        // Implement the logic to check if a record with the same ID and phone exists in your database
        // Return true if a record exists, false otherwise
        // Example:
        //int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        try (PreparedStatement statement = con.prepareStatement("SELECT COUNT(*) FROM stud_pho WHERE stud_id = ? AND phone = ?")) {
            statement.setInt(1, id);
            statement.setString(2, phone);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }

        return false;
    }

    public static boolean checkStudentExists(int id) throws SQLException {

        //int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        try (PreparedStatement statement = con.prepareStatement("SELECT COUNT(*) FROM student WHERE stud_id = ? ")) {
            statement.setInt(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }

        return false;
    }

    public static boolean checkprofExists(int id) throws SQLException {

        //int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        try (PreparedStatement statement = con.prepareStatement("SELECT COUNT(*) FROM professor WHERE professor_id = ? ")) {
            statement.setInt(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }

        return false;
    }

    public static boolean checkcourse_codeExists(int cid) throws SQLException {

        //int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        try (PreparedStatement statement = con.prepareStatement("SELECT COUNT(*) FROM course WHERE cid = ? ")) {
            statement.setInt(1, cid);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }

        return false;
    }

    public static boolean checkDepartmentExists(String departName) throws SQLException {
        //int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");

        try (PreparedStatement statement = con.prepareStatement("SELECT COUNT(*) FROM department WHERE dname = ? ")) {
            statement.setString(1, departName);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }

        return false;
    }

    public static int insertprofess_contact(int id, String p_pho) throws SQLException {

        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("insert into prof_pho values(?,?) ");

        pst.setInt(1, id);
        pst.setString(2, p_pho);

        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;

    }

    public static boolean checkprofContactExists(int id, String phone) throws SQLException {
        // Implement the logic to check if a record with the same ID and phone exists in your database
        // Return true if a record exists, false otherwise
        // Example:
        //int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        try (PreparedStatement statement = con.prepareStatement("SELECT COUNT(*) FROM prof_pho WHERE professor_id = ? AND phone = ?")) {
            statement.setInt(1, id);
            statement.setString(2, phone);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }

        return false;
    }

    public static int updatedepartment(String depart_name, String depart_desc, int manager) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        //delete
        PreparedStatement pst = con.prepareStatement("delete from department where DNAME=?");

        pst.setString(1, depart_name);

        result = pst.executeUpdate();
        //insert
        PreparedStatement i = con.prepareStatement("insert into department(DNAME , DEPT_DESCRIPTION,MANAGER_ID ) "
                + "values(?,?,?)");
        i.setString(1, depart_name);
        i.setString(2, depart_desc);
        i.setInt(3, manager);
        result = i.executeUpdate();

        pst.close();
        con.close();
        return result;
    }

    public static int deletedepartment(String depart_name) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("delete from department where dname=? ");
        pst.setString(1, depart_name);

        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;
    }

    public static int deletestudentpho(int id, String stu_pho) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("delete from stud_pho where stud_id=? and phone=?");

        pst.setInt(1, id);
        pst.setString(2, stu_pho);
        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;
    }

    public static int deleteprofpho(int id, String p_pho) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("delete from prof_pho where professor_id=? and phone=?");

        pst.setInt(1, id);
        pst.setString(2, p_pho);
        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;
    }
    public static int insert_course_grade(int id, int cid,String grade ) throws SQLException {
        int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        PreparedStatement pst = con.prepareStatement("insert into stud_course values(?,?,?)");

        pst.setInt(1, id);
       pst.setInt(2, cid);
        pst.setString(3, grade);
        result = pst.executeUpdate();
        pst.close();
        con.close();
        return result;
    }
       
     public static boolean check_course_codeExists(int id) throws SQLException {

        //int result = 0;
        DriverManager.registerDriver(new OracleDriver());
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "University", "123");
        try (PreparedStatement statement = con.prepareStatement("SELECT COUNT(*) FROM course WHERE cid = ? ")) {
            statement.setInt(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }

        return false;
    }
}
