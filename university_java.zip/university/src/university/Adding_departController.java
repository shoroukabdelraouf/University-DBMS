/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author shoroukabdelraouf
 */
public class Adding_departController implements Initializable {

    @FXML
    private BorderPane borderregisteration;
    @FXML
    private AnchorPane anchorregisteration;
    private TextField fnameTF;
    @FXML
    private TableView<prof_dto> managname;
    @FXML
    private TableColumn<prof_dto, Integer> manag_id;
    @FXML
    private TableColumn<prof_dto, String> manager_prof_fna;
    @FXML
    private TableView<depart_dto> departs_table;
    @FXML
    private TableColumn<depart_dto, String> depart_nam;
    @FXML
    private TableColumn<depart_dto, String> depart_desc;
    @FXML
    private TableColumn<depart_dto, Integer> managercol;
    @FXML
    private Button add_dep;
    @FXML
    private Text textmakeregisteration;
    @FXML
    private Button delete_dep;
    @FXML
    private Button update;
    @FXML
    private TableColumn<prof_dto, String> manager_l_nam;
    @FXML
    private TextField de_name;
    @FXML
    private TextField de_desc;
    @FXML
    private TextField assign;
    private boolean isTableVisible = false;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
//        ObservableList<prof_dto> manager = FXCollections.observableArrayList();
//
//        manag_id.setCellValueFactory(new PropertyValueFactory<>("professorId"));
//        manager_prof_fna.setCellValueFactory(new PropertyValueFactory<>("fname"));
//        manager_l_nam.setCellValueFactory(new PropertyValueFactory<>("lname"));
//
//        try {
//            manager = DAO.getmanager();
//        } catch (SQLException ex) {
//            Logger.getLogger(Adding_departController.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        managname.setItems(manager);

//        ObservableList<depart_dto> departments = FXCollections.observableArrayList();
//
//        depart_nam.setCellValueFactory(new PropertyValueFactory<>("dname"));
//        depart_desc.setCellValueFactory(new PropertyValueFactory<>("dept_description"));
//        managercol.setCellValueFactory(new PropertyValueFactory<>("managerId"));
//
//        try {
//            departments = DAO.getdepartments();
//        } catch (SQLException ex) {
//            Logger.getLogger(Adding_departController.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        departs_table.setItems(departments);
    }

    public void registerClear() {
        de_name.clear();
        de_desc.clear();
        assign.clear();

    }

//    @FXML
//    private void insert_department(ActionEvent event) throws SQLException {
//
//        String depart_name = de_name.getText();
//        String depart_desc = de_desc.getText();
//        String manager = assign.getText();
//
//        if (depart_name.isEmpty() || depart_desc.isEmpty() || manager.isEmpty()) {
//            JOptionPane.showMessageDialog(null, "All fields are necessary to be filled");
//            return;
//        }
//        int result;
//        result = DAO.insertdepartment(depart_name, depart_desc, Integer.parseInt(manager));
//        if (result > 0) {
//            System.out.println("Insert Successfully");
//            JOptionPane.showMessageDialog(null, "Department is  added Successfully");
//            registerClear();
//        } else {
//            System.out.println("Failed Insert");
//        }
//
//    }
    @FXML
    private void insert_department(ActionEvent event) throws SQLException {
        String depart_name = de_name.getText();
        String depart_desc = de_desc.getText();
        String manager = assign.getText();

        if (depart_name.isEmpty() || depart_desc.isEmpty() || manager.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All fields are necessary to be filled");
            return;
        }

        // Check if the manager with the given ID exists
        if (!isManagerExists(Integer.parseInt(manager))) {
            JOptionPane.showMessageDialog(null, "Please check our available managers. Manager with ID " + manager + " not found.");
            registerClear();
            return;
        }

        // Check if the department with the given name already exists
        if (DAO.checkDepartmentExists(depart_name)) {
            JOptionPane.showMessageDialog(null, "we have this department at  our university.");
            registerClear();
            return;
        }

        // Insert the new department
        int result = DAO.insertdepartment(depart_name, depart_desc, Integer.parseInt(manager));

        if (result > 0) {
            System.out.println("Insert Successfully");
            JOptionPane.showMessageDialog(null, "Department is added Successfully");
            registerClear();
        } else {
            System.out.println("Failed Insert");
            JOptionPane.showMessageDialog(null, "Department is not  added ");
        }
    }

//    @FXML
//    private void insert_department(ActionEvent event) throws SQLException {
//
//        String depart_name = de_name.getText();
//        String depart_desc = de_desc.getText();
//        String manager = assign.getText();
//
//        if (depart_name.isEmpty() || depart_desc.isEmpty() || manager.isEmpty()) {
//            JOptionPane.showMessageDialog(null, "All fields are necessary to be filled");
//            return;
//        }
//
//        // Check if the manager with the given ID exists
//        if (!isManagerExists(Integer.parseInt(manager))) {
//            JOptionPane.showMessageDialog(null, "Please check our available managers. Manager with ID " + manager + " not found.");
//            registerClear();
//            return;
//        }
//        boolean recordExists = DAO.checkStudentExists(depart_name);
//
//        if (recordExists) {
//            // Display a message or alert that the record already exists
//            JOptionPane.showMessageDialog(null, "this student is alerady enrolled in our university .");
//            registerClear();
//        } else {
//            int result;
//            result = DAO.insertdepartment(depart_name, depart_desc, Integer.parseInt(manager));
//
//            if (result > 0) {
//                System.out.println("Insert Successfully");
//                JOptionPane.showMessageDialog(null, "Department is added Successfully");
//                registerClear();
//            } else {
//                System.out.println("Failed Insert");
//            }
//        }
//    }

// Method to check if a manager with the given ID exists
    private boolean isManagerExists(int managerId) throws SQLException {
        // Implement the logic to check if the manager exists in your DAO class
        // You need to have a method in your DAO class to perform this check
        // For example, assuming you have a method isManagerExists in your DAO class:
        return DAO.checkprofExists(managerId);
    }

    @FXML
    private void update_department(ActionEvent event) throws SQLException {
        String depart_name = de_name.getText();
        String depart_desc = de_desc.getText();
        String manager = assign.getText();
        if (depart_name.isEmpty()) {
            JOptionPane.showMessageDialog(null, "name required to be filled");
            return;
        }
//                if (depart_name.isEmpty() || depart_desc.isEmpty() || manager.isEmpty()) {
//            JOptionPane.showMessageDialog(null, "All fields are necessary to be filled");
//            return;
//        }
        int result;
        result = DAO.updatedepartment(depart_name, depart_desc, Integer.parseInt(manager));
        if (result > 0) {
            System.out.println("updated Successfully");
            JOptionPane.showMessageDialog(null, "Department data Updated Successfully");
            registerClear();
        } else {
            System.out.println("Failed update");
        }

    }

    @FXML
    public void delete_department() {
        try {
            String depart_name = de_name.getText();
            String depart_desc = de_desc.getText();
            String manager = assign.getText();

            if (depart_name.isEmpty()) {
                JOptionPane.showMessageDialog(null, "required to  fill name");
                return;
            }

            int result = DAO.deletedepartment(depart_name); // Print the exception stack trace for debugging
            if (result > 0) {
                System.out.println("department deleted Successfully");
                JOptionPane.showMessageDialog(null, "deleted successfully");
                registerClear();
            } else {
                System.out.println("Failed to delete");
            }
            //Adding_departController.this.student = DAO.getAllstudent();
        } catch (SQLException ex) {
            Logger.getLogger(Adding_departController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void try1m(ActionEvent event) {
        // Assuming the following code is relevant for your UI update
        ObservableList<prof_dto> manager = FXCollections.observableArrayList();

        manag_id.setCellValueFactory(new PropertyValueFactory<>("professorId"));
        manager_prof_fna.setCellValueFactory(new PropertyValueFactory<>("fname"));
        manager_l_nam.setCellValueFactory(new PropertyValueFactory<>("lname"));
        try {
            manager = DAO.getmanager();
        } catch (SQLException ex) {
            Logger.getLogger(Adding_departController.class.getName()).log(Level.SEVERE, null, ex);
        }
        managname.setItems(manager);

        // Toggle the visibility of the table
        isTableVisible = !isTableVisible;
        managname.setVisible(isTableVisible);

        // Set the visibility of other elements
        setOtherElementsVisibility(!isTableVisible);

        // Set the alignment of the table within the StackPane
        StackPane.setAlignment(managname, Pos.CENTER);
    }

    @FXML
    private void try1d(ActionEvent event) {
        // Assuming the following code is relevant for your UI update
        ObservableList<depart_dto> departments = FXCollections.observableArrayList();

        depart_nam.setCellValueFactory(new PropertyValueFactory<>("dname"));
        depart_desc.setCellValueFactory(new PropertyValueFactory<>("dept_description"));
        managercol.setCellValueFactory(new PropertyValueFactory<>("managerId"));
        try {
            departments = DAO.getdepartments();
        } catch (SQLException ex) {
            Logger.getLogger(Adding_departController.class.getName()).log(Level.SEVERE, null, ex);
        }
        departs_table.setItems(departments);
        // Toggle the visibility of the table
        isTableVisible = !isTableVisible;
        departs_table.setVisible(isTableVisible);

        // Set the visibility of other elements
        setOtherElementsVisibility(!isTableVisible);

        // Set the alignment of the table within the StackPane
        StackPane.setAlignment(departs_table, Pos.CENTER);
    }

    private void setOtherElementsVisibility(boolean visible) {
        // Set the visibility of other elements (text fields) as needed
        de_name.setVisible(visible);
        de_desc.setVisible(visible);
        assign.setVisible(visible);

        // Add other text fields as needed
    }

}
