/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author shoroukabdelraouf
 */
public class ReportController implements Initializable {

    @FXML
    private BorderPane borderregisteration;
    @FXML
    private AnchorPane anchorregisteration;
    @FXML
    private TableView<report_dto> course_table;
    @FXML
    private TableColumn<report_dto, Integer> course_code;
    @FXML
    private TableColumn<report_dto, String> course_name;
    @FXML
    private TableColumn<report_dto, String> students_name;
    @FXML
    private TableColumn<report_dto, String> st_grade;
    @FXML
    private TableColumn<report_dto, Float> avg_gpa;
    @FXML
    private TableView<student_dto> student_table;
    @FXML
    private TableColumn<student_dto, Integer> st_id;
    @FXML
    private TableColumn<student_dto, String> st_fn;
    @FXML
    private TableColumn<student_dto, String> st_ln;
    @FXML
    private TableColumn<student_dto, String> st_gp;

    private boolean isTableVisible = false;
    @FXML
    private ChoiceBox<String> grade;
    private final String[] categories = {"A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "F"};
    @FXML
    private TextField c_code_gpa;
    @FXML
    private Button students_gpa;
    @FXML
    private Button course_get_gpa;
    @FXML
    private TextField stud_id;
    @FXML
    private TextField course_code_stud;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        grade.getItems().addAll(categories);
    }

    public void registerClear() {
        course_code_stud.clear();
        stud_id.clear();
        //grade.valueProperty().set(null);
        grade.setValue(null);
    }

    @FXML
    private void insert_student_grade(ActionEvent event) {
        try {
            String id = stud_id.getText();
            String c_code = course_code_stud.getText();
            String selectedGrade = grade.getValue(); // Assuming grade is a String ChoiceBox

            if (selectedGrade == null || selectedGrade.isEmpty()) {
                // Inform the user to choose a grade from the list
              
                JOptionPane.showMessageDialog(null, "Please choose a grade from the list.");
                // You can also display a dialog or label to inform the user
            }  boolean recordExists = DAO.check_course_codeExists(Integer.parseInt(id));

            if (recordExists) {
                // Display a message or alert that the record already exists
                JOptionPane.showMessageDialog(null, "this course is not available  .");
                registerClear();
            } else
            {
                int result;
                result = DAO.insert_course_grade(Integer.parseInt(id), Integer.parseInt(c_code), selectedGrade);
                if (result > 0) {
                    System.out.println("Insert Successfully");
                    JOptionPane.showMessageDialog(null, "Grade Added Successfully.");
                    registerClear();
                } else {
                    System.out.println("Failed Insert");
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ReportController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void students_info(ActionEvent event) {
        // Assuming the following code is relevant for your UI update
        ObservableList<student_dto> student = FXCollections.observableArrayList();
        st_id.setCellValueFactory(new PropertyValueFactory<>("studId"));
        st_fn.setCellValueFactory(new PropertyValueFactory<>("fname"));
        st_ln.setCellValueFactory(new PropertyValueFactory<>("lname"));
        st_gp.setCellValueFactory(new PropertyValueFactory<>("GPA"));
        try {
            student = DAO.get_student_info();

        } catch (SQLException ex) {
            Logger.getLogger(Adding_courseController.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        student_table.setItems(student);

        // Toggle the visibility of the table
        isTableVisible = !isTableVisible;
        student_table.setVisible(isTableVisible);

        // Set the visibility of other elements
        setOtherElementsVisibility(!isTableVisible);

        // Set the alignment of the table within the StackPane
        StackPane.setAlignment(student_table, Pos.CENTER);
    }

    @FXML
    private void course_gpa_info(ActionEvent event) throws SQLException {
        // Assuming the following code is relevant for your UI update
        ObservableList<report_dto> course_gpa = FXCollections.observableArrayList();
        course_code.setCellValueFactory(new PropertyValueFactory<>("cid"));
        course_name.setCellValueFactory(new PropertyValueFactory<>("cname"));
        students_name.setCellValueFactory(new PropertyValueFactory<>("sname"));
        st_grade.setCellValueFactory(new PropertyValueFactory<>("grade"));
        avg_gpa.setCellValueFactory(new PropertyValueFactory<>("avg_gpa"));
        course_gpa = DAO.course_gpa_info(c_code_gpa.getText());
        for (report_dto report : course_gpa) {
            System.out.println("Course Code: " + report.getCid());
            System.out.println("Course Name: " + report.getCname());
            System.out.println("Average GPA: " + report.getAvg_gpa());
            System.out.println("Student Name: " + report.getSname());
            System.out.println("Student Grade: " + report.getGrade());
            System.out.println("--------------------------");
        }
        course_table.setItems(course_gpa);

        // Toggle the visibility of the table
        isTableVisible = !isTableVisible;
        course_table.setVisible(isTableVisible);

        // Set the visibility of other elements
        setOtherElementsVisibility(!isTableVisible);

        // Set the alignment of the table within the StackPane
        StackPane.setAlignment(course_table, Pos.CENTER);
    }

    private void setOtherElementsVisibility(boolean visible) {

        // cname.setVisible(visible);
    }

}
