/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author shoroukabdelraouf
 */
public class course_dto {
    private int cid; 
    private String cname;
     private int cHours;
    private String dname;
    private int year;
    private int professorId;

    public course_dto(int cid, String cName) {
        this.cid = cid;
        this.cname = cName;
    }

    public course_dto(int cid, String cName, String dname) {
        this.cid = cid;
        this.cname = cName;
        this.dname = dname;
    }
   

  
  

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public int getcHours() {
        return cHours;
    }

    public void setcHours(int cHours) {
        this.cHours = cHours;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getProfessorId() {
        return professorId;
    }

    public void setProfessorId(int professorId) {
        this.professorId = professorId;
    }

    public course_dto(int cid, String cName, int cHours, String dname, int year, int professorId) {
        this.cid = cid;
        this.cname = cName;
        this.cHours = cHours;
        this.dname = dname;
        this.year = year;
        this.professorId = professorId;
    }
    
}
