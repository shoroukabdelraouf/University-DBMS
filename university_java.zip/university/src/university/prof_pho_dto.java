/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author shoroukabdelraouf
 */
public class prof_pho_dto {
    private int professorId; 
    private String phone;

    public int getProfessorId() {
        return professorId;
    }

    public void setProfessorId(int professorId) {
        this.professorId = professorId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public prof_pho_dto(int professorId, String phone) {
        this.professorId = professorId;
        this.phone = phone;
    }
    
    
}
