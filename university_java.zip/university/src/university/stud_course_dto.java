/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author shoroukabdelraouf
 */
public class stud_course_dto {
    private int stud_id ;
    private int cid;
    private String grade_;

    public stud_course_dto(int stud_id, int cid, String grade_) {
        this.stud_id = stud_id;
        this.cid = cid;
        this.grade_ = grade_;
    }
   
    
    
    
}
