/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author shoroukabdelraouf
 */
public class depart_dto {
    private String dname;
    private String dept_description;
    private int managerId;

    public String getDname() {
        return dname;
    }

    public depart_dto(String dname) {
        this.dname = dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getDept_description() {
        return dept_description;
    }

    public void setDept_description(String dept_description) {
        this.dept_description = dept_description;
    }

    public int getManagerId() {
        return managerId;
    }

    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

//    public depart_dto(String dname, String dept_description, int managerId) {
//        this.dname = dname;
//        this.dept_description = dept_description;
//        this.managerId = managerId;
//    }

    public depart_dto(String dname, String dept_description, int managerId) {
        this.dname = dname;
        this.dept_description = dept_description;
        this.managerId = managerId;
    }
    
    
}
