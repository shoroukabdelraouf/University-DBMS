/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

import java.net.URL;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.layout.StackPane;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author shoroukabdelraouf
 */
public class Adding_profController implements Initializable {

    @FXML
    private BorderPane borderregisteration;
    @FXML
    private AnchorPane anchorregisteration;
    @FXML
    private TextField fnameTF;
    @FXML
    private TextField lnameTF;
    @FXML
    private TextField emailTF;
    @FXML
    private TableView<depart_dto> depart_table;
    @FXML
    private Button add_prof;
    @FXML
    private TableColumn<prof_dto, Integer> prof_id;
    @FXML
    private TableColumn<prof_dto, String> prof_f_name;
    @FXML
    private TableColumn<prof_dto, String> prof_l_name;
    @FXML
    private TableColumn<prof_dto, String> prof_sal;
    @FXML
    private TableColumn<prof_dto, String> prof_email;
    @FXML
    private TableColumn<prof_dto, String> prof_addre;
    @FXML
    private TableColumn<prof_dto, String> prof_depart;
    @FXML
    private Text textmakeregisteration;
    @FXML
    private Button update_prof1;
    @FXML
    private Button del_prof11;
    @FXML
    private TableView<prof_dto> table_professor;
    @FXML
    private TableColumn<depart_dto, String> deparment_name;
    @FXML
    private TextField Salarytf;
    @FXML
    private TextField addresstf;
    @FXML
    private TextField departtf;
    @FXML
    private TextField idtf;
     private boolean isTableVisible = false;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }   
    
     public void registerClear() {
        idtf.clear();
        fnameTF.clear();
        lnameTF.clear();
        departtf.clear();
        emailTF.clear();
        addresstf.clear();
        Salarytf.clear();
       

    }
             String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
             @FXML
    private void insert_professor(ActionEvent event) {

        try {
            String id = idtf.getText();
            String fname = fnameTF.getText();
            String lname = lnameTF.getText();
            String email = emailTF.getText();
            String depart = departtf.getText();
            String add = addresstf.getText();
            String salary =Salarytf.getText();
           
            

            if (id.isEmpty() || fname.isEmpty() || lname.isEmpty() || depart.isEmpty()
                    || email.isEmpty() || add.isEmpty()|| salary.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are necessary to be filled");
                return;
            }

            String mail = emailTF.getText();
            if (!mail.matches(emailPattern)) {
                JOptionPane.showMessageDialog(null, "Provide a valid email.");
                return;
            }
             boolean recordExists = DAO.checkprofExists(Integer.parseInt(id));

            if (recordExists) {
                // Display a message or alert that the record already exists
                JOptionPane.showMessageDialog(null, "this professor is alerady teaches at our university .");
                registerClear();
            } else{

            int result;
            result = DAO.insertprofessor(Integer.parseInt(id), fname, lname, Integer.parseInt(salary), add, email, depart);
            if (result > 0) {
                System.out.println("Insert Successfully");
               JOptionPane.showMessageDialog(null, "Professor added Successfully");
                registerClear();
            } else {
                System.out.println("Failed Insert");
                
            }
        
            }
    }   catch (SQLException ex) {
            if (ex instanceof SQLIntegrityConstraintViolationException) {
                // Handle the case where the referential integrity constraint is violated
                JOptionPane.showMessageDialog(null, "there is no department with this name.");
                registerClear();
            } else {
                // Handle other SQLExceptions if needed
                ex.printStackTrace();
            }
        }
        
    }
    
    @FXML
    private void update_professor(ActionEvent event) {
        try {
            
             String id = idtf.getText();
            String fname = fnameTF.getText();
            String lname = lnameTF.getText();
            String email = emailTF.getText();
            String depart = departtf.getText();
            String add = addresstf.getText();
            String salary =Salarytf.getText();

//            if (id.isEmpty()) {
//                JOptionPane.showMessageDialog(null, "required");
//                return;
//            }
            
            if (id.isEmpty() || fname.isEmpty() || lname.isEmpty() || depart.isEmpty()
                    || email.isEmpty() || add.isEmpty()|| salary.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are necessary to be filled");
                return;
            }

            int result;                  
            result = DAO.updateprofessor(Integer.parseInt(id), fname, lname,Integer.parseInt(salary), add,  email, depart);
            if (result > 0) {
                System.out.println("updated Successfully");
                JOptionPane.showMessageDialog(null, " Updated Successfully");
                registerClear();
            } else {
                System.out.println("Failed update");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Adding_profController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    @FXML
    public void delete_prof() {
            String id = idtf.getText();
            String fname = fnameTF.getText();
            String lname = lnameTF.getText();
            String email = emailTF.getText();
            String depart = departtf.getText();
            String add = addresstf.getText();
            String salary =Salarytf.getText();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(null, "professor ID isrequired to be filled");
            return;
        }

        try {
            int result = DAO.deleteprof(Integer.parseInt(id));

            if (result > 0) {
                System.out.println("deleted Successfully");
                JOptionPane.showMessageDialog(null, "deleted successfully");
                registerClear();
            } else {
                System.out.println("Failed to delete");
            }
            //Adding_courseController.this.course = DAO.getAllcourse();
        } catch (SQLException ex) {
            ex.printStackTrace(); // Print the exception stack trace for debugging
            Logger.getLogger(Adding_profController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
        @FXML
   private void try1p(ActionEvent event) {
    // Assuming the following code is relevant for your UI update
    ObservableList<prof_dto> professor_prof= FXCollections.observableArrayList();

      prof_id.setCellValueFactory(new PropertyValueFactory<>("professorId"));
       prof_f_name.setCellValueFactory(new PropertyValueFactory<>("fname"));
        prof_l_name.setCellValueFactory(new PropertyValueFactory<>("lname"));
        prof_sal.setCellValueFactory(new PropertyValueFactory<>("salary"));
        prof_addre.setCellValueFactory(new PropertyValueFactory<>("address"));
        prof_email.setCellValueFactory(new PropertyValueFactory<>("email"));
        prof_depart.setCellValueFactory(new PropertyValueFactory<>("dname"));
     try {
            professor_prof= DAO.getProfessor();
        } catch (SQLException ex) {
            Logger.getLogger(Adding_profController.class.getName()).log(Level.SEVERE, null, ex);
        }
     table_professor.setItems(professor_prof);
    // Toggle the visibility of the table
    isTableVisible = !isTableVisible;
     table_professor.setVisible(isTableVisible);

    // Set the visibility of other elements
    setOtherElementsVisibility(!isTableVisible);

    // Set the alignment of the table within the StackPane
    StackPane.setAlignment( table_professor, Pos.CENTER);
} 
         @FXML
   private void try1d(ActionEvent event) {
    // Assuming the following code is relevant for your UI update
   ObservableList<depart_dto> department = FXCollections.observableArrayList();

      deparment_name.setCellValueFactory(new PropertyValueFactory<>("dname"));
       try {
            department = DAO.getdepart_name();
        } catch (SQLException ex) {
            Logger.getLogger(Adding_courseController.class.getName()).log(Level.SEVERE, null, ex);
        }
    depart_table.setItems(department);
    // Toggle the visibility of the table
    isTableVisible = !isTableVisible;
     depart_table.setVisible(isTableVisible);

    // Set the visibility of other elements
    setOtherElementsVisibility(!isTableVisible);

    // Set the alignment of the table within the StackPane
    StackPane.setAlignment( table_professor, Pos.CENTER);
}     

       

      
       
   
   
   

    private void setOtherElementsVisibility(boolean visible) {
    // Set the visibility of other elements (text fields) as needed
    fnameTF.setVisible(visible);
    lnameTF.setVisible(visible);
    emailTF.setVisible(visible);
    Salarytf.setVisible(visible);
    addresstf.setVisible(visible);
    departtf.setVisible(visible);
   idtf.setVisible(visible);
   
  
   
    // Add other text fields as needed
}

        
       
         

    
}
