/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

import java.net.URL;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author shoroukabdelraouf
 */
public class Adding_student_phoneController implements Initializable {

    @FXML
    private BorderPane bordercourse;
    @FXML
    private AnchorPane anchorregisteration;
    @FXML
    private TextField stud_pho;
    @FXML
    private TextField prof_pho;
    @FXML
    private TextField professor_id;
    @FXML
    private Button add_s_pho;
    @FXML
    private Text textmakeregisteration;
    @FXML
    private Button del_s_ph;
    @FXML
    private Button up_p_ph;
    @FXML
    private TextField student_id;
    @FXML
    private Button add_p_ph;
    @FXML
    private Button del_p_ph;
    @FXML
    private Button up_s_ph;
    @FXML
    private TableView<prof_pho_dto> prof_table;
    @FXML
    private TableColumn<prof_pho_dto, Integer> prof_id1;
    @FXML
    private TableColumn<prof_dto, String> prof_pho1;
    @FXML
    private TableColumn<stud_pho, Integer> stud_id1;
    @FXML
    private TableColumn<stud_pho, String> stud_pho1;
    @FXML
    private TableView<stud_pho> stud_pho_t;
     private boolean isTableVisible = false;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    public void registerClear() {

        stud_pho.clear();
        prof_pho.clear();
        professor_id.clear();
        student_id.clear();
    }

    @FXML
    private void add_student_contact(ActionEvent event) {
        String id = student_id.getText();
        String stu_pho = stud_pho.getText();

        if (id.isEmpty() || stu_pho.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All fields are necessary to be filled");
            return;
        }

        try {
            // Check if a record with the same ID and phone already exists
            boolean recordExists = DAO.checkStudentContactExists(Integer.parseInt(id), stu_pho);

            if (recordExists) {
                // Display a message or alert that the record already exists
                JOptionPane.showMessageDialog(null, "the same ID and phone already exists.");
            } else {
                // If the record doesn't exist, proceed with the insertion
                int result = DAO.insertstudent_contact(Integer.parseInt(id), stu_pho);

                if (result > 0) {
                    System.out.println("Insert Successfully");
                    JOptionPane.showMessageDialog(null, "phone added Successfully");
                    registerClear();
                } else {
                    System.out.println("Failed Insert");
                }
            }
        } catch (SQLException ex) {
            if (ex instanceof SQLIntegrityConstraintViolationException) {
                // Handle the case where the referential integrity constraint is violated
                JOptionPane.showMessageDialog(null, "No student found with the provided ID.");
                
            } else {
                // Handle other SQLExceptions if needed
                ex.printStackTrace();
            }
        }
    }

    @FXML
    private void del_stud_pho(ActionEvent event) {
        String id = student_id.getText();
        String stu_pho = stud_pho.getText();

        try {
            // Check if the student with the given ID and phone exists
            boolean exists = DAO.checkStudentContactExists(Integer.parseInt(id), stu_pho);

            if (exists) {
                int result = DAO.deletestudentpho(Integer.parseInt(id), stu_pho);

                if (result > 0) {
                    System.out.println("Deleted Successfully");
                    JOptionPane.showMessageDialog(null, "Deleted successfully");
                    registerClear();
                } else {
                    System.out.println("Failed to delete");
                }
            } else {
                // Display a message when there is no similar ID in the stud_pho table
                System.out.println("Student not found. Unable to delete.");
                JOptionPane.showMessageDialog(null, "this student has no phone number ");
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); // Print the exception stack trace for debugging
            Logger.getLogger(Adding_student_phoneController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void get_stud_con(ActionEvent event) {
       
    // Assuming the following code is relevant for your UI update
    ObservableList<stud_pho> student = FXCollections.observableArrayList();
    stud_id1.setCellValueFactory(new PropertyValueFactory<>("studId"));
    stud_pho1.setCellValueFactory(new PropertyValueFactory<>("phone"));
    try {
         student = DAO.getstud_con();
    } catch (SQLException ex) {
        Logger.getLogger(Adding_student_phoneController.class.getName()).log(Level.SEVERE, null, ex);
    }
    stud_pho_t.setItems( student);

    // Toggle the visibility of the table
    isTableVisible = !isTableVisible;
    stud_pho_t.setVisible(isTableVisible);

    // Set the visibility of other elements
    setOtherElementsVisibility(!isTableVisible);

    // Set the alignment of the table within the StackPane
    StackPane.setAlignment(stud_pho_t, Pos.CENTER);


   
    }

    @FXML
    private void add_prof_contact(ActionEvent event) {
        String id = professor_id.getText();
        String p_pho = prof_pho.getText();

        if (id.isEmpty() || p_pho.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All fields are necessary to be filled");
            return;
        }

        try {
            // Check if a record with the same ID and phone already exists
            boolean recordExists = DAO.checkprofContactExists(Integer.parseInt(id), p_pho);

            if (recordExists) {
                // Display a message or alert that the record already exists
                JOptionPane.showMessageDialog(null, "this professor is already exists.");
            } else {
                // If the record doesn't exist, proceed with the insertion
                int result = DAO.insertprofess_contact(Integer.parseInt(id), p_pho);

                if (result > 0) {
                    System.out.println("Insert Successfully");
                    JOptionPane.showMessageDialog(null, "phone added Successfully");
                    registerClear();
                } else {
                    System.out.println("Failed Insert");
                }
            }
        } catch (SQLException ex) {
            if (ex instanceof SQLIntegrityConstraintViolationException) {
                // Handle the case where the referential integrity constraint is violated
                JOptionPane.showMessageDialog(null, "No professor found with the provided ID.");
                registerClear();
            } else {
                // Handle other SQLExceptions if needed
                ex.printStackTrace();
            }
        }
    }

    @FXML
    private void del_prof_pho(ActionEvent event) {
        String id = professor_id.getText();
        String p_pho = prof_pho.getText();

        try {
            // Check if the student with the given ID and phone exists
            boolean exists = DAO.checkprofContactExists(Integer.parseInt(id), p_pho);

            if (exists) {
                int result = DAO.deleteprofpho(Integer.parseInt(id), p_pho);

                if (result > 0) {
                    System.out.println("Deleted Successfully");
                    JOptionPane.showMessageDialog(null, "Deleted successfully");
                    registerClear();
                } else {
                    System.out.println("Failed to delete");
                }
            } else {
                // Display a message when there is no similar ID in the stud_pho table
                System.out.println("Student not found. Unable to delete.");
                JOptionPane.showMessageDialog(null, "this professor has no phone number");
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); // Print the exception stack trace for debugging
            Logger.getLogger(Adding_student_phoneController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void get_prof_con(ActionEvent event) {
        // Assuming the following code is relevant for your UI update
    ObservableList<prof_pho_dto> professor = FXCollections.observableArrayList();
    prof_id1.setCellValueFactory(new PropertyValueFactory<>("professorId"));
    prof_pho1.setCellValueFactory(new PropertyValueFactory<>("phone"));
    try {
         professor = DAO.getprof_con();
    } catch (SQLException ex) {
        Logger.getLogger(Adding_student_phoneController.class.getName()).log(Level.SEVERE, null, ex);
    }
    prof_table.setItems( professor);

    // Toggle the visibility of the table
    isTableVisible = !isTableVisible;
    prof_table.setVisible(isTableVisible);

    // Set the visibility of other elements
    setElementsVisibility(!isTableVisible);

    // Set the alignment of the table within the StackPane
    StackPane.setAlignment(prof_table, Pos.CENTER);
    }
      private void setOtherElementsVisibility(boolean visible) {
    // Set the visibility of other elements (text fields) as needed
    stud_pho.setVisible(visible);
     student_id.setVisible(visible);
   
}
       private void setElementsVisibility(boolean visible) {
    // Set the visibility of other elements (text fields) as needed
    professor_id.setVisible(visible);
     prof_pho.setVisible(visible);
     
   
}

}
