/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * FXML Controller class
 *
 * @author shoroukabdelraouf
 */
public class Adding_studentController implements Initializable {

    @FXML
    private BorderPane borderregisteration;
    @FXML
    private AnchorPane anchorregisteration;
    @FXML
    private TextField fnameTF;
    @FXML
    private TextField lnameTF;
    @FXML
    private TextField emailTF;
    private TextField phoneTF;
    @FXML
    private Button register_stud_butt;
    @FXML
    private Text add_new_student;
    @FXML
    private TextField address;
    @FXML
    private TextField facultyTF;
    @FXML
    private TextField departTF;
    @FXML
    private Button update_stud_butt;
    @FXML
    private Button delete_stud_butt;
    @FXML
    private TextField genderTF;
    @FXML
    private TextField idTf;
    @FXML
    private Button get_stud_butt1;
    private ArrayList<student_dto> student;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    public void registerClear() {
        idTf.clear();
        fnameTF.clear();
        lnameTF.clear();
        address.clear();
        emailTF.clear();
        genderTF.clear();
        facultyTF.clear();
        departTF.clear();
       // phoneTF.clear();

    }
    String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";

    @FXML
    private void insert_student(ActionEvent event) {

        try {
            String id = idTf.getText();
            String fname = fnameTF.getText();
            String lname = lnameTF.getText();
            String email = emailTF.getText();
           // String phone = phoneTF.getText();
            String add = address.getText();
            String faculty = facultyTF.getText();
            String department = departTF.getText();
            String gender = genderTF.getText().toLowerCase();

            if (idTf.getText().isEmpty() || fnameTF.getText().isEmpty() || lnameTF.getText().isEmpty() || address.getText().isEmpty()
                    || emailTF.getText().isEmpty() || genderTF.getText().isEmpty()
                    || facultyTF.getText().isEmpty() ||  departTF.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are necessary to be filled");
                return;
            }
            

            String mail = emailTF.getText();
            if (!mail.matches(emailPattern)) {
                JOptionPane.showMessageDialog(null, "Provide a valid email.");
                return;
            }

            if (!gender.matches("[FfMm]")) {
                JOptionPane.showMessageDialog(null, "Gender should be 'F' or 'M'.");
                return;
            }
             boolean recordExists = DAO.checkStudentExists(Integer.parseInt(id));

            if (recordExists) {
                // Display a message or alert that the record already exists
                JOptionPane.showMessageDialog(null, "this student is already enrolled in our university .");
                registerClear();
            } else{

            int result;
            result = DAO.insertstudent(Integer.parseInt(id), fname, lname, add, email, gender, faculty, department);
            if (result > 0) {
                System.out.println("Insert Successfully");
                JOptionPane.showMessageDialog(null, "student enrolled Successfully.");
                registerClear();
            } else {
                System.out.println("Failed Insert");
                JOptionPane.showMessageDialog(null, "student didn't enrolle Successfully.");
            }
            }
        } catch (SQLException ex) {
            if (ex instanceof SQLIntegrityConstraintViolationException) {
                // Handle the case where the referential integrity constraint is violated
                JOptionPane.showMessageDialog(null, "there is no department with this name.");
                
            } else {
                // Handle other SQLExceptions if needed
                ex.printStackTrace();
            }
        }

    }

    @FXML
    private void update_student(ActionEvent event) {
        try {
            String id = idTf.getText();
            String fname = fnameTF.getText();
            String lname = lnameTF.getText();
            String email = emailTF.getText();
            String phone = phoneTF.getText();
            String add = address.getText();
            String faculty = facultyTF.getText();
            String department = departTF.getText();
            String gender = genderTF.getText().toLowerCase();

            if (idTf.getText().isEmpty() || fnameTF.getText().isEmpty() || lnameTF.getText().isEmpty() || address.getText().isEmpty()
                    || emailTF.getText().isEmpty() || genderTF.getText().isEmpty()
                    || facultyTF.getText().isEmpty() || departTF.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are necessary to be filled");
                return;
            }

            String mail = emailTF.getText();
            if (!mail.matches(emailPattern)) {
                JOptionPane.showMessageDialog(null, "Provide a valid email.");
                return;
            }

            if (!gender.matches("[FfMm]")) {
                JOptionPane.showMessageDialog(null, "Gender should be 'F' or 'M'.");
                return;
            }

            int result;
            result = DAO.updatestudent(Integer.parseInt(id), fname, lname, add, email, gender, faculty, department);
            if (result > 0) {
                System.out.println("updated Successfully");
                     JOptionPane.showMessageDialog(null, "Updated Successfully");
                registerClear();
            } else {
                System.out.println("Failed update");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Adding_studentController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    public void delete_student() {
        String id = idTf.getText();
        String fname = fnameTF.getText();
        String lname = lnameTF.getText();
        String email = emailTF.getText();
        String add = address.getText();
        String faculty = facultyTF.getText();
        String department = departTF.getText();
        String gender = genderTF.getText();

        try {
            int result = DAO.deletestudent(Integer.parseInt(id), fname, lname, add, email, gender, faculty, department);

            if (result > 0) {
                System.out.println("deleted Successfully");
                JOptionPane.showMessageDialog(null, "deleted successfully");
                registerClear();
            } else {
                System.out.println("Failed to delete");
                JOptionPane.showMessageDialog(null, "Failed to delete");
            }
            Adding_studentController.this.student = DAO.getAllstudent();
        } catch (SQLException ex) {
            ex.printStackTrace(); // Print the exception stack trace for debugging
            Logger.getLogger(Adding_studentController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    public void get_student() {
        String id = idTf.getText();

        try {
            ResultSet resultSet = DAO.getstudent(Integer.parseInt(id));

            if (resultSet.next()) {
                String studentInfo = resultSet.getString(1);

                JOptionPane.showMessageDialog(null, "Student Information:\n" + studentInfo,
                        "Student Information", JOptionPane.INFORMATION_MESSAGE);

                System.out.println("Retrieve Successfully");
                registerClear();
            } else {
                System.out.println("Failed to retrieve student information");
                JOptionPane.showMessageDialog(null, "this student is not enrolled");
            }

            // Close the ResultSet here, and then close the Connection
            resultSet.close();
            DAO.closeConnection(); // Add a method in your DAO class to close the connection

            // Assuming Adding_studentController.this.student = DAO.getAllstudent(); is used to refresh the student list
            Adding_studentController.this.student = DAO.getAllstudent();

        } catch (SQLException ex) {
            Logger.getLogger(Adding_studentController.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }
}
