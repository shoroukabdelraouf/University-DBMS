/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author shoroukabdelraouf
 */
public class student_dto {
    private int studId; 
    private String fname;
    private String lname;

    public student_dto(int studId, String fname, String lname, float GPA) {
        this.studId = studId;
        this.fname = fname;
        this.lname = lname;
        this.GPA = GPA;
    }
    private String address;
    private String email;
    private String gender;
    private String faculty;
    private String dname;
     private float GPA;

    public student_dto(int studId, String fname, String lname, String address, String email, String gender, String faculty, String dname) {
        this.studId = studId;
        this.fname = fname;
        this.lname = lname;
        this.address = address;
        this.email = email;
        this.gender = gender;
        this.faculty = faculty;
        this.dname = dname;
    }

    public int getStudId() {
        return studId;
    }

    public void setStudId(int studId) {
        this.studId = studId;
    }

    public String getFname() {
        return fname;
    }

    

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public float getGPA() {
        return GPA;
    }

    public void setGPA(float GPA) {
        this.GPA = GPA;
    }
   

  
    
}
